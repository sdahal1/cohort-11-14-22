const instructors = [
    {
        id: 1,
        name: {
            first: "Jessica",
            last: "Alba"
        }
    },
    {
        id: 2,
        name: {
            first: "Tony",
            last: "Robbins"
        }
    },
    {
        id: 3,
        name: {
            first: "Rob",
            last: "Dahal"
        }
    },
    {
        id: 4,
        name: {
            first: "Wayne",
            last: "Dyer"
        }
    }
]

module.exports = instructors;
