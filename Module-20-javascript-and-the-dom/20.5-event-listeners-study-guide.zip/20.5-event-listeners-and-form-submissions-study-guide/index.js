/* ~~~~~~~~~~~~~~~~~~~~~~~~ 20.5 Event Listeners ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
function expandArticleBody() {
    
}

function crossOffArticle() {
    
}


  
function main() {
    expandArticleBody();
    crossOffArticle();
}
  